// ───────────────────────────────────────────────────────────────────────────────────────────────
//  TEMPLATE for a new command.   Copy this file into  plugins/  (that folder is loaded at start-up; this one is not).
//
//  That is ALL you have to do. She learns the command by herself from the cmd({ … }) below:
//
//      • typed:   /weather colombo     (normal users: she does it for them, in her own voice)
//      • spoken:  "weather colombo"    (first word = the command name, or an alias of 3+ letters)
//      • missing argument → she asks ("which city?") and uses the next message
//      • category 'group' → group admins only · category 'owner' → the owner only · otherwise everybody
//      • she is told the command exists, so she can also start it from normal wording (read-only commands only)
//
//  What she reads:
//      pattern / alias   the names
//      desc              what it does (English, short: it is shown to her AI)
//      use               ← the line that matters:   '.weather <city>'      <word> = required   [word] = optional
//                           <url>/<link> → a link · <number> → a phone number · @user → a tagged / replied person
//                           on/off → a switch · anything else → free text · several parts → the whole rest as it is
//      category          'group' | 'owner' | anything else
//
//  A command is picked up when it has a `use:` line (or a `gf:` block). Commands without one are left manual, and names that
//  look dangerous (eval, broadcast, delete, fake …) need an explicit `gf: { … }`.   See everything she knows:  /gf tools
// ───────────────────────────────────────────────────────────────────────────────────────────────
const { cmd } = require('../command');

cmd({
    pattern: 'weather',
    alias: ['wx', 'klimate'],
    desc: 'Weather forecast of a city',
    use: '.weather <city>',
    category: 'tools',
    filename: __filename,

    // ── OPTIONAL: only when you want to change what she works out herself ─────────────────────────
    // gf: {
    //     keywords: ['weather', 'කාලගුණය', 'wessa'],   // words (Sinhala / Singlish / English) that should make her think of this command
    //     ask: { si: 'මොන නගරයද?', en: 'Which city?' },  // her own question when the argument is missing
    //     hint: 'city weather forecast',                  // ≤ 40 chars, English, what the AI is told (default: desc)
    //     arg: 'text', req: true,                          // none | url | text | number | target | onoff | raw
    //     perm: 'any',                                     // any | group-admin | owner
    //     group: false, confirm: false, quoted: false,     // group only? ask "sure?" first? needs a replied message?
    //     marker: true,                                    // may her AI start it by itself? (only for harmless, read-only commands)
    //     extract: (text, { urls, quotedText }) => text,   // your own way of cutting the argument out of the message
    // },
    // gf: false,                                           // never let her use this command
},
async (conn, mek, m, { from, q, reply }) => {
    if (!q) return reply('Usage: .weather <city>');           // q = the argument, exactly as if it had been typed
    // …call your weather API here…
    await reply(`☀️ ${q}: 31°C, partly cloudy`);
});
